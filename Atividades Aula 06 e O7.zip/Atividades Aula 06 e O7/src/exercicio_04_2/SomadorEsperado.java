package exercicio_04_2;

public interface SomadorEsperado {
	int somaVetor(int[] vetor);
}
