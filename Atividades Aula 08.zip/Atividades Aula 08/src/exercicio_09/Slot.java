package exercicio_09;



public interface Slot {
	public double recebeMoeda(int m);
	public void setSlot(Slot s);
}
