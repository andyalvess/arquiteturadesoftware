package exercicio_05;

public class IOTest {

	public static void main(String[] args) {
		
		IOFacade iof = new IOFacade();
		byte[] byteArray = {1,2,3,4,5};
		iof.gravarArquivoBinario("sys.bin", byteArray);
		iof.lerArquivoBinario("sys.bin");
		iof.gravarArquivoTexto("sys.txt", "conteudo teste");
		iof.lerArquivoTexto("sys.txt");
	}
}
