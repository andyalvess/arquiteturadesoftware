package exercicio_06_2;

public interface SelectionSort {
	void sort(double[] a);
}
