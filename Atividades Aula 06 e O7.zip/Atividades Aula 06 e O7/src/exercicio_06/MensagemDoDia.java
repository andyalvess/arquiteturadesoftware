package exercicio_06;

public interface MensagemDoDia {
	void imprimir();
}
