package exercicio_06;

public class MensagemSexta implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � sexta-feira.");
	}
}
