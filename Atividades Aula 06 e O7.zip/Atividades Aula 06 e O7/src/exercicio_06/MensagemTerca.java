package exercicio_06;

public class MensagemTerca implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � ter�a-feira.");
	}
}
