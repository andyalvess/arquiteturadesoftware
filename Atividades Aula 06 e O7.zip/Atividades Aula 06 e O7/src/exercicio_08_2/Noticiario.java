package exercicio_08_2;

public abstract class Noticiario {
	public abstract void notificaNoticia(String textoNoticia, int dia, int mes, String topico);
}
