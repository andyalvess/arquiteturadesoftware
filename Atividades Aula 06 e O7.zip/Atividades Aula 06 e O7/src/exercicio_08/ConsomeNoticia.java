package exercicio_08;

public interface ConsomeNoticia {     
	public void notificaNoticia(String textoNoticia, int dia, int mes, String topico);
} 


